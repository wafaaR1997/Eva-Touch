<?php

// get cats and it's subs .
// this method isn't good , but easier . we don't have time :)


$products_main_cats = $db->getRows("SELECT * FROM products_main_categories");
$services_main_cats = $db->getRows("SELECT * FROM services_main_categories");
//
$products_sub_cats = $db->getRows("SELECT * FROM products_sub_categories");
$services_sub_cats = $db->getRows("SELECT * FROM services_sub_categories");

?>

<div class="right_content">
    <div class="title"><span class="title_icon"><img src="images/bullet3.png" alt=""/></span>About Us</div>
    <div class="about">
        <p><img width=100 height=120 src="images/about.png" alt="" class="right"/>this website is my gift for each woman
            that has unique identity and touch that makes her special.for each woman driven by innovation and passion to
            make extraordinary crafts that express her creativity talent and feminine nature<br><br></p>
    </div>
    <div class="right_box">
        <div class="title"><span class="title_icon"><img src="images/promotion.png" alt=""/></span>Promotions</div>
        <div class="new_prod_box"><a href="#">Food</a>
            <div class="new_prod_bg"><span class="new_icon"><img width=150 height=120 src="images/food.jpeg"
                                                                 alt=""/></span> <a href="#"><img
                            src="images/thumb1.gif" alt="" class="thumb" border="0"/></a></div>
        </div>
        <br>
        <div class="new_prod_box"><a href="#">Tutor</a>
            <div class="new_prod_bg"><span class="new_icon"><img width=150 height=120 src="images/teacher.jpg" alt=""/></span>
                <a href="#"><img src="images/thumb2.gif" alt="" class="thumb" border="0"/></a></div>
        </div>
        <br>
        <div class="new_prod_box"><a href="#">Photographer</a>
            <div class="new_prod_bg"><span class="new_icon"><img width=150 height=120 src="images/photographer.jpg"
                                                                 alt=""/></span> <a href="#"><img
                            src="images/thumb3.gif" alt="" class="thumb" border="0"/></a></div>
        </div>
        <br>
    </div>
    <div class="right_box">
        <div class="title"><span class="title_icon"><img src="images/services.png" alt=""/></span>
            <small>Products & Service</small>
        </div>
        <ul class="list">

            <?php foreach ($products_main_cats as $product_main_cat) : ?>
            <li><b><span class="title_icon"><img src="<?= $product_main_cat->icon_path ?>"
                                                 height="26" width="26"/><?= ucwords(strtolower($product_main_cat->name)) ?></b>
                <ul><br><br>
                    <?php foreach ($products_sub_cats as $product_sub_cat) : ?>
                    <?php if ($product_sub_cat->main_category_id == $product_main_cat->id ) : ?>
                        <li><a href="lister.php?type=1&id=<?= $product_sub_cat->id; ?>"><?= ucwords(strtolower($product_sub_cat->name)); ?></a></li>
                    <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            </li>
            <?php endforeach; ?>

            <?php foreach ($services_main_cats as $service_main_cat) : ?>
                <li><b><span class="title_icon"><img src="<?= $service_main_cat->icon_path ?>"
                                                     height="26" width="26"/><?= ucwords(strtolower($service_main_cat->name)) ?></b>
                    <ul><br><br>
                        <?php foreach ($services_sub_cats as $service_sub_cat) : ?>
                        <?php if ($service_sub_cat->main_category_id == $service_main_cat->id ) : ?>
                            <li><a href="lister.php?type=2&id=<?= $service_sub_cat->id; ?>"><?= ucwords(strtolower($service_sub_cat->name)); ?></a></li>
                        <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </li>
            <?php endforeach; ?>


    </div>
</div>
