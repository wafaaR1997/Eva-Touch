<?php



class DB
{
    /**
     * @var \mysqli
     */
    private $connection;

    public $last_query;

    public function __construct($host, $user, $pass, $db_name)
    {
        @$this->connection = mysqli_connect($host, $user, $pass, $db_name) or die("Cannot connect to database");
        $this->connection->set_charset("utf8");

    }

    public function query($sql)
    {
        $this->last_query = $sql;
        return $this->connection->query($sql);
    }

    /**
     * Get Fields as array of objects
     *
     * @param $sql
     * @return array
     */
    public function getRows($sql)
    {
        $result = $this->query($sql);
        $out = [];
        if ($result)
            for ($i = 0; $i < $result->num_rows; $i++) {
                $out[] = (object)$result->fetch_assoc();
            }
        return $out;
    }

    /**
     * get one row from db
     * @param $sql
     * @return bool|object
     */
    public function getRow($sql)
    {
        $result = $this->query($sql);
        if (is_object($result))
            return $result->num_rows > 0 ? (object)$result->fetch_assoc() : false;
        return false;
    }

    public function escape($str)
    {
        return $this->real_escape_string($str);
    }

    public function insert($table, array $data)
    {
        $sql = "INSERT INTO $table ";

        $cols = array_keys($data);
        $sql .= "(" . implode(',', $cols) . ") VALUES ";
        $sql .= $this->prepareInsertValues($data);

        $result = $this->query($sql);
        $insert_id = $this->connection->insert_id;
        return $result ? $insert_id ? $insert_id : true : false;

    }

    public function insert_multi($table, $cols_array, $data_array)
    {
        $sql = "INSERT INTO $table ";
        $sql .= "(" . implode(',', $cols_array) . ") VALUES ";
        $values = [];
        foreach ($data_array as $row) {
            $values[] = $this->prepareInsertValues($row);
        }
        $sql .= join(",", $values);
        return $this->query($sql);
    }

    public function prepareInsertValues($data) {
        // phone number workaround
        if (isset($data['phone'])) $data['phone'] .= " ";


        $vals = array_values($data);
        $sql = "(";
        $i = 0;
        foreach ($vals as $val) {
            $sql .= $this->check($val); /* super :P */
            $sql .= $i++ < count($vals) - 1 ? "," : "";
        }
        $sql .= ")";

        return $sql;
    }



    public function update($table, array $data, $where)
    {
        $sql = "UPDATE $table SET ";

        // phone number workaround
        if (isset($data['phone'])) $data['phone'] .= " ";

        $set = [];
        foreach ($data as $col => $val) {
            $set[] = "$col = " . $this->check($val);
        }
        $sql .= implode(' , ', $set);
        $sql .= " WHERE $where";
        return $this->query($sql);
    }



    public function last_error()
    {
        return "QUERY: " . $this->last_query . "\nERROR MESSAGE:" . $this->connection->error;
    }

    public function check($val)
    {
        return (is_string($val) ? '"' . $this->escape(trim($val)) . '"' : $this->escape($val));
    }

    public function insert_id()
    {
        return $this->connection->insert_id;
    }

}