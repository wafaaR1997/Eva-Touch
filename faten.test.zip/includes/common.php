<?php
date_default_timezone_set('Asia/Amman');
// global vars
include_once "globals.php";

// Utils
include_once "Utils/Auth.php";

include_once "functions.php";


// Objects



//$datetime = date('d-m-Y h:i:s A');
$date = date('d-m-Y');
$unixtime = strtotime($date);


