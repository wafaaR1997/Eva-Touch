<?php

// Domain name of the site
define("DNSURL", 'faten.test');

// your host ip or name
define("DB_HOST", 'localhost');

// username for database connection
define("DB_USER", 'root');

// password for database connection
define("DB_PASS", '');

// database name
define("DB_NAME", 'eva_touch_db');



define("DOC_ROOT", rtrim($_SERVER['DOCUMENT_ROOT'], '/'));