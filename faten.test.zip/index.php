<?php
require "includes/includes.php";

$promotion_products = $db->getRows("SELECT * FROM products WHERE is_promoted = 1");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Eav touch - Home</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style> 


.checked {
    color: orange;
	padding:5px;
}


</style>
</head>
<body>
<div id="wrap">
  <?php include "views/header.php"; ?>
  
 <div class="center_content">
    <div class="left_content">
      <div class="title"><span class="title_icon"><img src="images/featuredProd.png" alt="" /></span>Featured Products</div>

     <?php if ($promotion_products) : ?>
     <?php foreach ($promotion_products as $promotion_product) : ?>
      <div class="feat_prod_box">
        <div class="prod_img"><a href="#"><img width=150 height=150 src="<?= $promotion_product->product_image_path; ?>" alt="" border="0" /></a></div>
        <div class="prod_det_box">
          <div class="box_top"></div>
          <div class="box_center">
            <div style=color:#000000 class="prod_title"><b> <?= $promotion_product->product_name; ?> </b></div><br>
            <p style=color:#990000 class="details">


                <b>price : <?= $promotion_product->price; ?> $</b>

                <br>

                <b>Status :<span
                            style="color: <?= $productStatus[$promotion_product->product_status][1] ?>;"> <?= $productStatus[$promotion_product->product_status][0]; ?></span></b>
                <br>
                <b> Phone : <span style="color:black"><?= $promotion_product->phone ?></span></b>
                <br>
                <b>Description : <span style="color:black"><?= $promotion_product->description ?></span></b>
                <br>

			</p>


			</p>

            <div class="clear"></div>
          </div>
          <div class="box_bottom"></div>
        </div>
        <div class="clear"></div>
      </div>
        <?php endforeach;?>
        <?php endif;?>

      <div class="clear"></div>
    </div>
	
    
    <!--end of left content-->


     <?php include "views/right_sidebar.php"; ?>
    <!--end of right content-->
   <div class="clear"></div>
  </div>
  <!--end of center content-->
<div class="footer">
    <div class="right_footer"> <a href="#">home</a> <a href="#">about us</a> <a href="#">my account</a> <a href="#">register</a> <a href="#">contact us</a> </div>
  </div>
</div>
</body>
</html>