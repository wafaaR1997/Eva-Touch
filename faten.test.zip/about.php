<?php
require "includes/includes.php";
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Eav touch - About</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
<div id="wrap">
    <?php include "views/header.php"; ?>
  <div class="center_content">
    <div class="left_content">
      <div class="title"><span class="title_icon"><img src="images/bullet3.png" alt="" /></span>About us</div>
      <div class="feat_prod_box_details">
        <p class="details"> <img width=150 height=80 src="images/q.jpg" alt="" class="right" />
		Eva  Touches Website is to showcase the women talents and innovation in their crafts and show the woman's important role in the community and that she can be the change maker with her project and she can earn living for her family.
Eva Touches Website is the dream we saw in each talented woman who wants to start her own small business to earn her living. So we want to help that dream of drawing the smile on others faces by crafts made by women who wants to increase their income.
<br><br><br>
- Website objectives and what makes it different:<br>
<br>1. Start small free marketing projects for each woman that has talent.
<br>2. Support and empower women by increasing her role in developing and building the
community.

<br>3. Satisfying the market demands by providing products that suits the customers around the clock.

<br>5. Customers get the best service from website  because the site can  displays the services and product sorted   by  quality .
<br>6. Following up with what is new and innovative in handcrafts.
<br>7. Allow the customers to provide feedback for the product and services  to improve the products and provide support.
<br>8. Connect all women in one place so they can use their diversity to enrich and learn
from each others.
<br>9. Allow amateurs and interested women to learn and gain apprenticeship and make their
own crafts.
<br>10. Save time and effort while looking for what is unique and extraordinary with suitable
prices.
<br>11. The seller can  Watching  the ratings and opinions of customer  about them  products and services that will help them to be better .
		
		
		</p>
      </div>
      <div class="clear"></div>
    </div>
    <!--end of left content-->

      <?php include "views/right_sidebar.php"; ?>

    <!--end of right content-->
    <div class="clear"></div>
  </div>
  <!--end of center content-->
  <div class="footer">
    <div class="right_footer"> <a href="#">home</a> <a href="#">about us</a> <a href="#">my account</a> <a href="#">register</a> <a href="#">contact us</a> </div>
  </div>
</div>
</body>
</html>
